WHAT IT DOES:
-------------
This module adds a new field type for referencing roles in content types.

TO INSTALL:
-----------
Nothing special. Drop the rolereference folder into the 'modules'
directory of your Drupal installation.

UPGRADE:
-----------
No upgrade from Drupal 6.x at this point.

BUGS & ISSUES:
--------------
http://drupal.org/project/issues/rolereference

SPONSOR:
--------
Classic Graphics <http://www.cgraphics.com/>
