
This directory should be used to place downloaded and custom modules
and themes which are common to all sites. Keeping contributed and
custom modules and themes in the sites directory will aid in upgrading
Drupal core files. Place contributed and custom modules and themes in
the sites/all/modules and sites/all/themes directories respectively.

